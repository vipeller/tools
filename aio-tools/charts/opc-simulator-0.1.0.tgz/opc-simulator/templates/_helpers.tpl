{{/*
Expand the name of the chart.
*/}}
{{- define "opc-simulator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name. Truncated at 63 chars
because some Kubernetes name fields are limited to this (RFC 1123).
*/}}
{{- define "opc-simulator.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart name + version label, per Helm best practice.
*/}}
{{- define "opc-simulator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels applied to every resource. `commonLabels` is merged
last so user-supplied labels can override the defaults if needed.
*/}}
{{- define "opc-simulator.labels" -}}
helm.sh/chart: {{ include "opc-simulator.chart" . }}
{{ include "opc-simulator.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Selector labels — must be stable across upgrades (Deployment selectors
are immutable in K8s), so they DO NOT include version.
*/}}
{{- define "opc-simulator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opc-simulator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Service account name resolution.
*/}}
{{- define "opc-simulator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "opc-simulator.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/*
Hard-fail at template-render time if the user forgot to supply an
image reference. This catches the most common misconfiguration
before it manifests as an `ImagePullBackOff`.
*/}}
{{- define "opc-simulator.image" -}}
{{- if not .Values.image -}}
{{- fail "values.image is required. Set --set image=<registry>/opc-simulator:<tag> (e.g. the output of deploy/scripts/build-and-push.sh)" -}}
{{- end -}}
{{- .Values.image -}}
{{- end -}}
